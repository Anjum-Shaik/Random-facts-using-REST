package com.cat.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cat.rest.service.FactService;


@RestController

public class fact {
	@Autowired
	private FactService factService;
	
	
	@GetMapping("/catfact.ninja/fact")
	
	
	public String getAllFacts() {
		String response = factService.getAllFacts();
		return response;
		
}

	public FactService getFactService() {
		return factService;
	}

	public void setFactService(FactService factService) {
		this.factService = factService;
	}
}
