package com.cat.rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service

public class FactServiceImpl implements FactService {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	
	public String getAllFacts() {
		String result = restTemplate.getForObject("https://catfact.ninja/fact", String.class);
		System.out.println(result);
		
		return result;
		
	
	
	}

}
