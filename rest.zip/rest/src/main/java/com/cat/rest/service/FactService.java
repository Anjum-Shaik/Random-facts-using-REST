package com.cat.rest.service;

public interface FactService {
	
	public String getAllFacts();
	

}
